import type { ReactNode } from "react";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none" aria-hidden="true">
      <path d="M8 18L32 8l24 10-24 10L8 18Z" fill="currentColor" opacity="0.95" />
      <path d="M18 25v14c0 7.18 6.27 13 14 13s14-5.82 14-13V25" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M56 18v17" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
      <path d="M56 35c-2.5 0-4.5 2.24-4.5 5s2 5 4.5 5 4.5-2.24 4.5-5-2-5-4.5-5Z" fill="currentColor" opacity="0.7" />
    </svg>
  );
}

export function HomeIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="M3 10.5 12 3l9 7.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M5 9.5V21h14V9.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function GridIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <rect x="3" y="3" width="7" height="7" rx="2" />
      <rect x="14" y="3" width="7" height="7" rx="2" />
      <rect x="3" y="14" width="7" height="7" rx="2" />
      <rect x="14" y="14" width="7" height="7" rx="2" />
    </svg>
  );
}

export function SearchIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-4.35-4.35" strokeLinecap="round" />
    </svg>
  );
}

export function HeartIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="M12 20.5s-7-4.45-7-10.25C5 7.35 7.24 5 10 5c1.65 0 3.04.81 4 2.05C14.96 5.81 16.35 5 18 5c2.76 0 5 2.35 5 5.25 0 5.8-7 10.25-7 10.25H12Z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function HeartFilledIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="M12 20.5s-7-4.45-7-10.25C5 7.35 7.24 5 10 5c1.65 0 3.04.81 4 2.05C14.96 5.81 16.35 5 18 5c2.76 0 5 2.35 5 5.25 0 5.8-7 10.25-7 10.25H12Z" />
    </svg>
  );
}

export function CartIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="M3 4h2l2.2 10.2a2 2 0 0 0 2 1.55H18a2 2 0 0 0 1.96-1.61L21 8H7" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="10" cy="20" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="18" cy="20" r="1.4" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function UserIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <circle cx="12" cy="8" r="4" />
      <path d="M4 20c1.8-3.6 5-5.5 8-5.5S18.2 16.4 20 20" strokeLinecap="round" />
    </svg>
  );
}

export function HelpIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <circle cx="12" cy="12" r="9" />
      <path d="M9.75 9.25a2.45 2.45 0 1 1 4.15 1.77c-.87.81-1.9 1.45-1.9 3" strokeLinecap="round" />
      <circle cx="12" cy="17.2" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function MoonIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true"><path d="M20.5 14.2A8.9 8.9 0 0 1 9.8 3.5 9 9 0 1 0 20.5 14.2Z" /></svg>;
}

export function SunIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2.5v2.2M12 19.3v2.2M4.7 4.7l1.55 1.55M17.75 17.75l1.55 1.55M2.5 12h2.2M19.3 12h2.2M4.7 19.3l1.55-1.55M17.75 6.25l1.55-1.55" strokeLinecap="round" />
    </svg>
  );
}

export function ChevronDownIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="m6 9 6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function ChevronLeftIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="m15 6-6 6 6 6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function ChevronRightIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="m9 6 6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function MenuIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round" />
    </svg>
  );
}

export function CloseIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="M6 6l12 12M18 6 6 18" strokeLinecap="round" />
    </svg>
  );
}

export function ArrowRightIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="M5 12h14" strokeLinecap="round" />
      <path d="m13 6 6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function SlidersIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <path d="M4 6h12" strokeLinecap="round" />
      <circle cx="19" cy="6" r="2" />
      <path d="M4 12h4" strokeLinecap="round" />
      <circle cx="11" cy="12" r="2" />
      <path d="M16 12h4" strokeLinecap="round" />
      <path d="M4 18h12" strokeLinecap="round" />
      <circle cx="19" cy="18" r="2" />
    </svg>
  );
}

export function StarIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="m12 2.5 2.9 6 6.6.95-4.8 4.65 1.15 6.65L12 17.5l-5.85 3.25L7.3 14.1 2.5 9.45l6.6-.95L12 2.5Z" />
    </svg>
  );
}

export function FacebookIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true"><path d="M13.5 21v-7h2.4l.4-2.8h-2.8V9.4c0-.8.3-1.4 1.5-1.4h1.4V5.5C16.3 5.4 15.6 5.3 14.7 5.3c-2 0-3.4 1.2-3.4 3.5v2.4H8.8V14h2.5v7h2.2Z" /></svg>;
}

export function InstagramIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="1.9">
      <rect x="4" y="4" width="16" height="16" rx="5" />
      <circle cx="12" cy="12" r="3.5" />
      <circle cx="17" cy="7" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function WhatsAppIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true"><path d="M12 3.5a8.5 8.5 0 0 0-7.3 12.8L3.5 20.5l4.4-1.1A8.5 8.5 0 1 0 12 3.5Zm0 1.7a6.8 6.8 0 0 1 5.7 10.5 6.8 6.8 0 0 1-8.9 2.3l-.3-.2-2.6.7.7-2.5-.2-.3A6.8 6.8 0 0 1 12 5.2Zm-2.4 3.4c-.1 0-.3 0-.5.2-.2.2-.6.6-.6 1.4 0 .8.6 1.6.7 1.7.1.1 1.2 2 3 2.7 1.5.6 1.8.5 2.1.5.3 0 1-.4 1.2-.8.1-.4.1-.7.1-.8l-.5-.3s-1-.5-1.2-.5c-.1-.1-.2-.1-.4.1l-.5.6c-.1.2-.2.2-.4.1-.2-.1-.8-.3-1.5-1-.6-.5-.9-1.1-1-1.3-.1-.2 0-.3.1-.4l.3-.4.2-.4v-.3l-.5-1.2c-.1-.3-.2-.2-.4-.2h-.4Z" /></svg>;
}

export function TikTokIcon({ className }: { className?: string }) {
  return <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true"><path d="M14 3.5c.3 1.9 1.4 3.4 3.3 3.7v2.5c-1.2 0-2.3-.4-3.3-1V15a5 5 0 1 1-5-5c.3 0 .6 0 .8.1v2.6a2.4 2.4 0 1 0 1.7 2.3V3.5H14Z" /></svg>;
}

export function FacebookCircleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="11" fill="currentColor" />
      <path d="M13.2 16h-1.9v-5.4h1.7l.2-1.95h-1.9V7.3c0-.5.2-.8.9-.8h1V4.8c-.2 0-.8-.08-1.55-.08-1.6 0-2.65 1-2.65 2.8v1.15H9v1.95h1.9V16h2.3v-5.4Z" fill="white" />
    </svg>
  );
}

export function InstagramCircleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="11" fill="currentColor" />
      <circle cx="12" cy="12" r="4.5" fill="none" stroke="white" strokeWidth="1.8" />
      <rect x="6.5" y="6.5" width="11" height="11" rx="3" fill="none" stroke="white" strokeWidth="1.8" />
      <circle cx="16.8" cy="7.2" r="1.1" fill="white" />
    </svg>
  );
}

export function WhatsAppCircleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="11" fill="currentColor" />
      <path d="M12.8 6.5a6.3 6.3 0 0 0-5.5 9.4l-.4 2.3 2.4-.6a6.3 6.3 0 1 0 3.5-11.1ZM15.5 14.2c-.2 0-1.2-.6-1.4-.6s-.2 0-.3.2c-.1.2-.4.6-.5.7-.1.1-.2.1-.3.08a2 2 0 0 1-.95-.5c-.9-.9-1.5-2-1.5-2.3 0-.2.1-.3.2-.4.1-.1.2-.2.3-.3.1-.1.2-.2.3-.3.1-.1.1-.2.2-.3.1-.1.2-.3.3-.4.1-.1.2-.2.3-.2s.2 0 .3.1c.2.1.9 1.1 1.1 1.3.1.1.2.2.2.4 0 .2-.1.3-.2.5-.1.1-.2.2-.3.3-.1.1-.2.2-.3.3-.1.1-.2.3-.3.4-.1.1-.2.2-.3.3-.1.1-.2.2-.2.3-.1.1-.2.2-.2.2-.1.1-.1.2-.1.2-.1 0-.1 0-.1.1-.1 0 0 .2.1.3.1.1.2.3.4.6.2.3.5.7 1 1.2.6.6 1.2 1.1 1.6 1.4.4.2.7.4.9.5.4.2.8.3 1.1.2.4-.1 1.1-.5 1.2-1 .2-.5.2-.9.2-1 .1-.1.1-.2 0-.3-.1-.1-.2-.2-.3-.3Z" fill="white" />
    </svg>
  );
}

export function TikTokCircleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="11" fill="currentColor" />
      <path d="M12.9 7.4c.2 1.4 1 2.5 2.3 2.8v1.9c-.9 0-1.7-.3-2.4-.8v4a3.8 3.8 0 1 1-3.8-3.8c.2 0 .5 0 .7.1v2a1.9 1.9 0 1 0 1.3 1.8V7.4h1.9Z" fill="white" />
    </svg>
  );
}

export const SOCIAL_ICONS: Array<{ label: string; Icon: ({ className }: { className?: string }) => ReactNode }> = [
  { label: "Facebook", Icon: FacebookCircleIcon },
  { label: "Instagram", Icon: InstagramCircleIcon },
  { label: "WhatsApp", Icon: WhatsAppCircleIcon },
  { label: "TikTok", Icon: TikTokCircleIcon },
];
