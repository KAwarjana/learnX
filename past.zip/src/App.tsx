import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { cn } from "./utils/cn";
import {
  ArrowRightIcon,
  CartIcon,
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  CloseIcon,
  GridIcon,
  HeartFilledIcon,
  HeartIcon,
  HelpIcon,
  LogoMark,
  MenuIcon,
  MoonIcon,
  SearchIcon,
  SlidersIcon,
  SOCIAL_ICONS,
  SunIcon,
  UserIcon,
} from "./ui/icons";

/* ============================================
   TYPES
   ============================================ */

type Theme = "light" | "dark";
type Page = "home" | "classes" | "about" | "contact" | "dashboard" | "wishlist" | "cart" | "profile" | "support";

type TabKey = "popular" | "newest" | "featured";

type ClassCard = {
  id: string;
  subject: string;
  title: string;
  teacher: string;
  price: number;
  oldPrice: number;
  day: string;
  duration: string;
  seats: string;
  rating: number;
  cover: string;
};

type FilterGroup = {
  title: string;
  options: string[];
};

type CategoryGroup = {
  title: string;
  items: string[];
};

type PageCard = {
  title: string;
  description: string;
  meta: string;
};

type PageDetail = {
  eyebrow: string;
  title: string;
  description: string;
  cards: PageCard[];
};

type SearchItem = {
  label: string;
  description: string;
  page: Page;
};

/* ============================================
   NAVIGATION
   ============================================ */

const NAV_ITEMS: Array<{ key: Page; label: string }> = [
  { key: "home", label: "Home" },
  { key: "about", label: "About" },
  { key: "contact", label: "Contact" },
  { key: "dashboard", label: "Dashboard" },
];

/* ============================================
   CATEGORY GROUPS (with "All" added)
   ============================================ */

const CATEGORY_GROUPS: CategoryGroup[] = [
  {
    title: "All Classes",
    items: ["All"],
  },
  {
    title: "Technology",
    items: ["Web Development", "Mobile Apps", "Cloud Computing", "Cyber Security"],
  },
  {
    title: "Creative",
    items: ["UI/UX Design", "Motion Graphics", "Video Editing", "Brand Design"],
  },
  {
    title: "Business",
    items: ["Digital Marketing", "Project Management", "Leadership", "Finance Basics"],
  },
  {
    title: "Languages",
    items: ["English Mastery", "Japanese", "Korean", "IELTS Preparation"],
  },
];

/* ============================================
   PAGE DETAILS
   ============================================ */

const PAGE_DETAILS: Record<Page, PageDetail> = {
  home: {
    eyebrow: "Welcome to Learnex",
    title: "Your Learning Journey Starts Here",
    description:
      "Discover thousands of classes across multiple subjects. Start learning today with expert teachers.",
    cards: [
      {
        title: "Wide Selection",
        description: "Choose from hundreds of classes across multiple subjects and grades.",
        meta: "500+ classes",
      },
      {
        title: "Expert Teachers",
        description: "Learn from qualified educators with years of experience.",
        meta: "Top rated",
      },
      {
        title: "Flexible Learning",
        description: "Access classes anytime, anywhere with our online platform.",
        meta: "24/7 access",
      },
    ],
  },
  about: {
    eyebrow: "About page",
    title: "Built for a modern learning marketplace",
    description:
      "The header is designed to feel like a production-ready e-learning site with clear navigation, utility actions, and category discovery.",
    cards: [
      {
        title: "Responsive layout",
        description: "Desktop keeps a full navigation bar while mobile uses a right-to-left slide panel.",
        meta: "Adaptive navigation",
      },
      {
        title: "Interactive utilities",
        description: "Search, categories, theme switcher, help shortcut, and profile menus all work.",
        meta: "Usable interactions",
      },
      {
        title: "Reusable structure",
        description: "This layout is easy to connect to real APIs, routing, and authentication later.",
        meta: "Scalable foundation",
      },
    ],
  },
  contact: {
    eyebrow: "Contact page",
    title: "Fast access to support and sales conversations",
    description:
      "The call-to-action button in the main navigation highlights contact access, while the help icon takes users to support quickly.",
    cards: [
      {
        title: "Help shortcut",
        description: "Hover reveals the label and click opens the support page state.",
        meta: "Support-first UX",
      },
      {
        title: "Contact CTA",
        description: "A bold pill button keeps conversion-friendly communication visible in the header.",
        meta: "Prominent CTA",
      },
      {
        title: "Search assist",
        description: "Users can search pages and category terms from the header without leaving context.",
        meta: "Quick find",
      },
    ],
  },
  dashboard: {
    eyebrow: "Member dashboard",
    title: "A signed-in experience centered on quick actions",
    description:
      "Once authenticated, the header prioritizes shopping and account access with wishlist, cart, and profile shortcuts.",
    cards: [
      {
        title: "Wishlist count",
        description: "Saved items are surfaced with a notification badge for instant awareness.",
        meta: "2 saved items",
      },
      {
        title: "Cart count",
        description: "The cart badge shows a pending checkout state from anywhere in the site.",
        meta: "1 active item",
      },
      {
        title: "Profile controls",
        description: "Hover or click opens account options including dashboard, profile, and sign out.",
        meta: "Account menu ready",
      },
    ],
  },
  wishlist: {
    eyebrow: "Wishlist page",
    title: "Saved learning paths, ready to revisit",
    description: "This page state demonstrates the redirect behavior from the heart icon in the utility bar.",
    cards: [
      {
        title: "Advanced React Patterns",
        description: "Component architecture, performance, and scalable state management.",
        meta: "Saved 3 hours ago",
      },
      {
        title: "UI Motion for Product Teams",
        description: "Create meaningful interaction design with motion systems and timing.",
        meta: "Saved yesterday",
      },
      {
        title: "Cloud Fundamentals",
        description: "A practical foundation for deployment, storage, and infrastructure basics.",
        meta: "Recommended for you",
      },
    ],
  },
  cart: {
    eyebrow: "Cart page",
    title: "Checkout-ready courses with a clear purchase state",
    description: "This page state demonstrates the redirect behavior from the cart icon in the utility bar.",
    cards: [
      {
        title: "Frontend System Design",
        description: "A premium cohort for building resilient, scalable front-end systems.",
        meta: "LKR 12,500 • 1 item",
      },
      {
        title: "Order summary",
        description: "Subtotal, discount options, and payment actions can be expanded here later.",
        meta: "Checkout flow placeholder",
      },
      {
        title: "Secure handoff",
        description: "The header layout is ready to integrate with real cart APIs and auth sessions.",
        meta: "Integration ready",
      },
    ],
  },
  profile: {
    eyebrow: "Profile page",
    title: "A compact account hub reached from the profile menu",
    description: "The profile icon opens a small menu on hover and click, then redirects to this page state when selected.",
    cards: [
      {
        title: "Personal details",
        description: "Display account basics, preferences, and saved settings in a clean layout.",
        meta: "Profile settings",
      },
      {
        title: "Theme preference",
        description: "The current visual mode is persisted locally so the header stays consistent.",
        meta: "Light/Dark saved",
      },
      {
        title: "Session controls",
        description: "Users can sign out from the same compact menu used for profile navigation.",
        meta: "Quick account actions",
      },
    ],
  },
  support: {
    eyebrow: "Help center",
    title: "Instant access to support guidance from the header",
    description: "Hovering the help icon reveals its label, and clicking it redirects here for guidance and service links.",
    cards: [
      {
        title: "FAQ access",
        description: "A simple destination for onboarding, payments, accounts, and technical help.",
        meta: "Self-service support",
      },
      {
        title: "Live assistance",
        description: "This section can later connect to chat, email, or ticket systems.",
        meta: "Extensible support",
      },
      {
        title: "Context-aware help",
        description: "The header keeps help accessible without cluttering the main navigation.",
        meta: "Always discoverable",
      },
    ],
  },
};

const PAGE_KEYS: Page[] = ["home", "classes", "about", "contact", "dashboard", "wishlist", "cart", "profile", "support"];

/* ============================================
   PRODUCT CATALOG DATA
   ============================================ */

const PRODUCT_FILTER_GROUPS: FilterGroup[] = [
  {
    title: "By Grade",
    options: ["Grade 06", "Grade 07", "Grade 08", "Grade 09", "Grade 10"],
  },
  {
    title: "By Subject",
    options: ["Biology", "ICT", "Physics", "Mathematics", "Sinhala"],
  },
  {
    title: "By Type",
    options: ["Paper Class", "Theory Class", "Revision Class"],
  },
];

const TABS: Array<{ key: TabKey; label: string }> = [
  { key: "popular", label: "Lorem Ipsum" },
  { key: "newest", label: "Lorem Ipsum" },
  { key: "featured", label: "Lorem Ipsum" },
];

const COVER_IDEAS: ClassCard[] = [
  {
    id: "c1",
    subject: "Business",
    title: "Topic For A Class",
    teacher: "Mr. Lorem Ipsum",
    price: 4000,
    oldPrice: 4900,
    day: "JAN 24",
    duration: "20.00 HRS",
    seats: "20/25",
    rating: 4.8,
    cover:
      "linear-gradient(135deg, #0f172a 0%, #1e3a8a 45%, #0f172a 100%), radial-gradient(circle at 70% 20%, rgba(96,165,250,0.35), transparent 50%)",
  },
  {
    id: "c2",
    subject: "Business",
    title: "Topic For A Class",
    teacher: "Mr. Lorem Ipsum",
    price: 4000,
    oldPrice: 4900,
    day: "JAN 24",
    duration: "20.00 HRS",
    seats: "20/25",
    rating: 4.6,
    cover:
      "linear-gradient(135deg, #111827 0%, #1e40af 50%, #0f172a 100%), radial-gradient(circle at 30% 80%, rgba(59,130,246,0.3), transparent 55%)",
  },
  {
    id: "c3",
    subject: "Business",
    title: "Topic For A Class",
    teacher: "Mr. Lorem Ipsum",
    price: 4000,
    oldPrice: 4900,
    day: "JAN 24",
    duration: "20.00 HRS",
    seats: "20/25",
    rating: 4.9,
    cover:
      "linear-gradient(135deg, #020617 0%, #1d4ed8 40%, #0c4a6e 100%), radial-gradient(circle at 80% 60%, rgba(37,99,235,0.35), transparent 55%)",
  },
  {
    id: "c4",
    subject: "Business",
    title: "Topic For A Class",
    teacher: "Mr. Lorem Ipsum",
    price: 4000,
    oldPrice: 4900,
    day: "JAN 24",
    duration: "20.00 HRS",
    seats: "20/25",
    rating: 4.7,
    cover:
      "linear-gradient(135deg, #111827 0%, #2563eb 45%, #1e293b 100%), radial-gradient(circle at 50% 50%, rgba(37,99,235,0.25), transparent 60%)",
  },
  {
    id: "c5",
    subject: "Business",
    title: "Topic For A Class",
    teacher: "Mr. Lorem Ipsum",
    price: 4000,
    oldPrice: 4900,
    day: "JAN 24",
    duration: "20.00 HRS",
    seats: "20/25",
    rating: 4.5,
    cover:
      "linear-gradient(135deg, #0c1c38 0%, #1d4ed8 50%, #111827 100%), radial-gradient(circle at 20% 40%, rgba(59,130,246,0.35), transparent 60%)",
  },
  {
    id: "c6",
    subject: "Business",
    title: "Topic For A Class",
    teacher: "Mr. Lorem Ipsum",
    price: 4000,
    oldPrice: 4900,
    day: "JAN 24",
    duration: "20.00 HRS",
    seats: "20/25",
    rating: 4.4,
    cover:
      "linear-gradient(135deg, #0b1220 0%, #1e3a8a 55%, #0f172a 100%), radial-gradient(circle at 90% 30%, rgba(37,99,235,0.35), transparent 60%)",
  },
];

const FOOTER_LINKS: Array<{ label: string; page: Page }> = [
  { label: "Privacy Policy", page: "support" },
  { label: "Terms & Conditions", page: "support" },
  { label: "FAQ", page: "support" },
];

/* ============================================
   UTILITIES
   ============================================ */

function getInitialTheme(): Theme {
  if (typeof window === "undefined") {
    return "light";
  }
  const storedTheme = window.localStorage.getItem("learnex-theme");
  return storedTheme === "dark" ? "dark" : "light";
}

function getInitialAuth(): boolean {
  if (typeof window === "undefined") {
    return false;
  }
  return window.localStorage.getItem("learnex-auth") === "true";
}

function getInitialPage(): Page {
  if (typeof window === "undefined") {
    return "classes";
  }
  const hash = window.location.hash.replace("#", "");
  return PAGE_KEYS.includes(hash as Page) ? (hash as Page) : "classes";
}

function formatLKR(value: number): string {
  return `LKR ${value.toLocaleString("en-LK")}`;
}

function classCardList(): ClassCard[] {
  const extended: ClassCard[] = [];
  for (let i = 0; i < 40; i += 1) {
    const template = COVER_IDEAS[i % COVER_IDEAS.length];
    extended.push({ ...template, id: `c-${i + 1}` });
  }
  return extended;
}

/* ============================================
   SUB-COMPONENTS
   ============================================ */

function TooltipIconButton({
  theme,
  label,
  onClick,
  children,
}: {
  theme: Theme;
  label: string;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className={cn(
        "group relative inline-flex h-11 w-11 items-center justify-center rounded-full border transition duration-200",
        theme === "light"
          ? "border-slate-200 bg-white text-sky-600 hover:border-sky-200 hover:bg-sky-50"
          : "border-slate-800 bg-black text-sky-400 hover:border-slate-700 hover:bg-slate-900",
      )}
    >
      {children}
      <span
        className={cn(
          "pointer-events-none absolute -bottom-10 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-xs font-semibold opacity-0 shadow-sm transition duration-200 group-hover:opacity-100",
          theme === "light" ? "bg-slate-900 text-white" : "bg-white text-slate-900",
        )}
      >
        {label}
      </span>
    </button>
  );
}

function FilterOptions({
  theme,
  selectedFilterCheckboxes,
  onToggleCheckbox,
}: {
  theme: Theme;
  selectedFilterCheckboxes: string[];
  onToggleCheckbox: (option: string) => void;
}) {
  return (
    <>
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-lg font-bold">
          <SlidersIcon className="h-5 w-5 text-sky-600" />
          Filter Options
        </h2>
      </div>

      <div className="mt-4 space-y-5">
        {PRODUCT_FILTER_GROUPS.map((group) => (
          <div key={group.title} className="py-2">
            <div className="flex items-center gap-2">
              <div className="h-5 w-1 rounded-full bg-sky-500" />
              <p className="text-sm font-bold uppercase tracking-tight">{group.title}</p>
            </div>
            <div className="mt-3 space-y-2 pl-3">
              {group.options.map((option) => {
                const checked = selectedFilterCheckboxes.includes(option);
                return (
                  <label key={option} className="flex cursor-pointer items-center gap-2 text-sm">
                    <span
                      className={cn(
                        "grid h-4 w-4 flex-shrink-0 place-items-center rounded-full border-2 transition",
                        checked
                          ? "border-sky-600 bg-sky-600"
                          : theme === "light"
                            ? "border-slate-300 bg-white"
                            : "border-slate-600 bg-slate-900",
                      )}
                    >
                      {checked && <span className="h-1.5 w-1.5 rounded-full bg-white" />}
                    </span>
                    <button
                      type="button"
                      onClick={() => onToggleCheckbox(option)}
                      className={cn(
                        "text-left transition",
                        theme === "light" ? "text-slate-700 hover:text-sky-600" : "text-slate-300 hover:text-sky-400",
                      )}
                    >
                      {option}
                    </button>
                  </label>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function ClassCardItem({
  card,
  theme,
  isWishlisted,
  onToggleWishlist,
}: {
  card: ClassCard;
  theme: Theme;
  index: number;
  isWishlisted: boolean;
  onToggleWishlist: () => void;
}) {
  return (
    <div className="group flex flex-col">
      <div
        className="relative aspect-[4/5] overflow-hidden bg-gradient-to-b from-slate-900 via-blue-950 to-slate-950"
        style={{ borderRadius: "1.25rem" }}
      >
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "radial-gradient(circle at 80% 20%, rgba(96,165,250,0.45), transparent 50%), repeating-linear-gradient(135deg, rgba(255,255,255,0.05) 0 1px, transparent 1px 16px), linear-gradient(180deg, #0f172a, #1e3a8a 45%, #0f172a)",
          }}
          aria-hidden
        />

        <div className="absolute left-3 top-3 z-10 inline-flex items-center rounded-full bg-sky-500 px-3.5 py-1 text-[11px] font-bold text-white shadow-md">
          {card.subject}
        </div>

        <div className="absolute inset-x-0 top-12 z-10 flex flex-col items-center text-center text-white">
          <h3 className="font-black tracking-tight text-[26px] leading-none">WEBINAR</h3>
          <div className="mt-1 inline-flex items-center gap-1.5 text-[10px] font-semibold tracking-[0.18em]">
            <span>Live Streaming</span>
            <span className="grid h-3.5 w-3.5 place-items-center rounded-full bg-red-600 text-[8px] text-white">●</span>
          </div>
        </div>

        <div className="absolute left-3 top-[95px] z-10 flex items-center gap-2 text-white">
          <span className="grid h-5 w-5 place-items-center rounded-full bg-white/15 text-white">
            <UserIcon className="h-3 w-3" />
          </span>
          <div>
            <p className="text-[8px] uppercase tracking-widest text-white/70">Presenter</p>
            <p className="text-[10px] font-semibold leading-tight">Robin Smith</p>
          </div>
        </div>

        <div className="absolute left-3 bottom-24 z-10 flex items-center gap-2">
          <div className="grid h-11 w-11 place-items-center rounded-full bg-white text-slate-900 shadow-md">
            <div className="text-center leading-none">
              <p className="text-[13px] font-black">{card.day.split(" ")[1]}</p>
              <p className="text-[8px] font-bold uppercase tracking-widest">{card.day.split(" ")[0]}</p>
            </div>
          </div>
          <div className="rounded-md bg-sky-500 px-2.5 py-1 text-white shadow-md">
            <p className="text-[10px] font-bold uppercase leading-none">Pukul.</p>
            <p className="text-[10px] font-extrabold leading-tight">20.00 WIB</p>
            <p className="text-[8px] font-semibold uppercase opacity-90">Selesai</p>
          </div>
        </div>

        <div className="absolute bottom-0 right-3 z-0 h-1/2 w-1/2">
          <svg viewBox="0 0 200 260" className="h-full w-full" preserveAspectRatio="xMidYMax meet" aria-hidden>
            <defs>
              <linearGradient id="suitGrad3" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1e293b" />
                <stop offset="100%" stopColor="#0f172a" />
              </linearGradient>
            </defs>
            <path d="M30 260 L30 180 Q30 130 70 120 L130 120 Q170 130 170 180 L170 260 Z" fill="url(#suitGrad3)" />
            <path d="M85 120 L100 145 L115 120 L100 130 Z" fill="white" />
            <path d="M97 130 L103 130 L107 175 L100 195 L93 175 Z" fill="#1d4ed8" />
            <circle cx="100" cy="85" r="32" fill="#f1c6a0" />
            <path d="M68 82 Q68 52 100 50 Q132 52 132 82 L128 77 Q118 62 100 62 Q82 62 72 77 Z" fill="#3a2418" />
            <circle cx="90" cy="88" r="2" fill="#1e293b" />
            <circle cx="110" cy="88" r="2" fill="#1e293b" />
          </svg>
        </div>

        <div className="absolute inset-x-3 bottom-3 z-10 flex items-center gap-1 rounded-full bg-gradient-to-r from-sky-500 to-blue-600 px-3 py-1.5 shadow-lg">
          <div className="flex-1">
            <p className="text-[13px] font-black uppercase tracking-tight text-white leading-none">Business</p>
            <p className="text-[11px] font-black uppercase tracking-tight text-white/90 leading-none">Conference</p>
          </div>
          <div className="h-7 w-px bg-white/40" />
          <div className="text-right">
            <p className="text-[8px] font-bold uppercase text-white/90 leading-tight">Business</p>
            <p className="text-[8px] font-bold uppercase text-white/90 leading-tight">Training</p>
            <p className="text-[8px] font-bold uppercase text-white/90 leading-tight">Start-Up</p>
            <p className="text-[8px] font-bold uppercase text-white/90 leading-tight">Strategies</p>
          </div>
        </div>

        <button
          type="button"
          aria-label="Toggle wishlist"
          onClick={onToggleWishlist}
          className={cn(
            "absolute right-3 top-3 z-20 grid h-8 w-8 place-items-center rounded-full bg-white/95 text-sky-600 shadow-md transition-all duration-300",
            "lg:invisible lg:opacity-0 lg:translate-y-1 lg:group-hover:visible lg:group-hover:opacity-100 lg:group-hover:translate-y-0",
            "opacity-100 translate-y-0",
            isWishlisted ? "bg-sky-600 text-white" : "hover:bg-sky-50",
          )}
        >
          {isWishlisted ? <HeartFilledIcon className="h-4 w-4" /> : <HeartIcon className="h-4 w-4" />}
        </button>
      </div>

      <div className={cn("mt-2 text-left", theme === "light" ? "bg-white" : "bg-slate-900")}>
        <p className={cn("text-[12px] font-medium", theme === "light" ? "text-slate-500" : "text-slate-400")}>
          {card.teacher}
        </p>
        <p className={cn("mt-1 text-[16px] font-extrabold leading-snug sm:text-[17px]", theme === "light" ? "text-slate-900" : "text-white")}>
          {card.title}
        </p>

        <div className="mt-2 flex flex-wrap items-center gap-2">
          <span className={cn("text-[14px] font-extrabold", theme === "light" ? "text-sky-600" : "text-sky-400")}>
            {formatLKR(card.price)}
          </span>
          <span className={cn("text-[12px] font-medium line-through", theme === "light" ? "text-slate-400" : "text-slate-500")}>
            {formatLKR(card.oldPrice)}
          </span>
        </div>
      </div>
    </div>
  );
}

/* ============================================
   HOME PAGE (Product Catalog)
   ============================================ */

function ClassesPage({ theme }: { theme: Theme }) {
  const [tab, setTab] = useState<TabKey>("popular");
  const [sortOpen, setSortOpen] = useState(false);
  const [sortValue, setSortValue] = useState("Default Sorting");
  const [activeFilters, setActiveFilters] = useState<string[]>(["Lorem Ipsum", "Lorem Ipsum", "Lorem Ipsum"]);
  const [selectedFilterCheckboxes, setSelectedFilterCheckboxes] = useState<string[]>([]);
  const [wishlist, setWishlist] = useState<Record<string, boolean>>({});
  const [page, setPage] = useState(1);
  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState(false);

  const filterRef = useRef<HTMLDivElement>(null);
  const sortRef = useRef<HTMLDivElement>(null);

  const classes = useMemo(() => classCardList(), []);
  const totalItems = 500;
  const itemsPerPage = 15;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const pageClasses = useMemo(() => classes.slice(0, itemsPerPage), [classes]);

  useEffect(() => {
    const handleMouseDown = (event: MouseEvent) => {
      const target = event.target as Node;
      if (sortRef.current && !sortRef.current.contains(target)) setSortOpen(false);
    };
    document.addEventListener("mousedown", handleMouseDown);
    return () => document.removeEventListener("mousedown", handleMouseDown);
  }, []);

  useEffect(() => {
    document.body.style.overflow = isFilterDrawerOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isFilterDrawerOpen]);

  const toggleWishlist = (id: string) => {
    setWishlist((current) => ({ ...current, [id]: !current[id] }));
  };

  const toggleCheckbox = (option: string) => {
    setSelectedFilterCheckboxes((current) =>
      current.includes(option) ? current.filter((item) => item !== option) : [...current, option],
    );
  };

  const removeActiveFilter = (filter: string) => {
    const index = activeFilters.indexOf(filter);
    if (index === -1) return;
    const next = [...activeFilters];
    next.splice(index, 1);
    setActiveFilters(next);
  };

  return (
    <>
      {/* Hero */}
      <section
        className={cn(
          "relative overflow-hidden transition-colors duration-300",
          theme === "light" ? "bg-gradient-to-b from-sky-100 via-sky-50 to-slate-100" : "bg-gradient-to-b from-blue-950 via-slate-950 to-slate-950",
        )}
      >
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              theme === "light"
                ? "radial-gradient(ellipse at center top, rgba(56,189,248,0.35), transparent 60%), linear-gradient(180deg, rgba(59,130,246,0.18), transparent 60%)"
                : "radial-gradient(ellipse at center top, rgba(29,78,216,0.55), transparent 60%), linear-gradient(180deg, rgba(15,23,42,0.9), transparent 60%)",
          }}
          aria-hidden
        />
        <div className="relative mx-auto max-w-[1400px] px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
          <div className="text-center">
            <h1
              className={cn(
                "text-[18vw] font-black leading-none tracking-tight sm:text-[140px] md:text-[180px]",
                theme === "light" ? "text-slate-800" : "text-white",
              )}
            >
              Classes
            </h1>
            <div
              className={cn(
                "mx-auto -mt-6 inline-flex items-center justify-center rounded-full border-2 px-6 py-2 sm:-mt-8 sm:px-8 sm:py-3",
                theme === "light"
                  ? "border-sky-200 bg-white text-slate-700"
                  : "border-blue-700 bg-slate-950 text-white",
              )}
            >
              <p className="font-serif italic text-base sm:text-lg md:text-xl">Give All You Need…</p>
            </div>
          </div>
        </div>
      </section>

      {/* Catalog */}
      <section className="w-full px-4 py-6 sm:px-6 lg:px-8">
        <div
          className={cn(
            "grid gap-4 rounded-[1.5rem] border p-4 shadow-lg sm:p-5 lg:grid-cols-[260px_1fr]",
            theme === "light" ? "border-slate-200 bg-white shadow-slate-200/60" : "border-slate-800 bg-slate-900 shadow-black/20",
          )}
        >
          {/* Filter panel */}
          <aside
            ref={filterRef}
            className={cn(
              "hidden pr-2 lg:sticky lg:top-36 lg:block lg:max-h-[calc(100vh-160px)] lg:self-start lg:overflow-y-auto",
            )}
          >
            <FilterOptions
              theme={theme}
              selectedFilterCheckboxes={selectedFilterCheckboxes}
              onToggleCheckbox={toggleCheckbox}
            />
          </aside>

          {/* Content panel */}
          <div className="min-w-0">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <button
                  type="button"
                  onClick={() => setIsFilterDrawerOpen(true)}
                  className="inline-flex items-center gap-2 rounded-full bg-sky-600 px-4 py-2 text-sm font-semibold text-white shadow-md shadow-sky-600/20 transition hover:bg-sky-500 lg:hidden"
                >
                  <SlidersIcon className="h-4 w-4" />
                  Filters
                  {selectedFilterCheckboxes.length > 0 && (
                    <span className="grid h-5 min-w-5 place-items-center rounded-full bg-white px-1 text-[11px] font-black text-sky-600">
                      {selectedFilterCheckboxes.length}
                    </span>
                  )}
                </button>
                <span className={cn("font-medium", theme === "light" ? "text-slate-700" : "text-slate-300")}>
                  Showing 1 - 10 of {totalItems.toLocaleString()} results
                </span>
              </div>

              <div ref={sortRef} className="relative flex items-center gap-2 text-sm">
                <span className={cn("font-medium", theme === "light" ? "text-slate-700" : "text-slate-300")}>
                  Sort by :
                </span>
                <button
                  type="button"
                  onClick={() => setSortOpen((current) => !current)}
                  className={cn(
                    "inline-flex min-w-[180px] items-center justify-between gap-3 rounded-full border px-4 py-2 text-sm font-medium",
                    theme === "light"
                      ? "border-slate-200 bg-white text-slate-800"
                      : "border-slate-700 bg-slate-950 text-white",
                  )}
                >
                  {sortValue}
                  <ChevronDownIcon className={cn("h-4 w-4 transition", sortOpen && "rotate-180")} />
                </button>

                {sortOpen && (
                  <div
                    className={cn(
                      "absolute right-0 top-full z-30 mt-2 w-64 overflow-hidden rounded-2xl border shadow-lg",
                      theme === "light" ? "border-slate-200 bg-white text-slate-900" : "border-slate-800 bg-slate-900 text-white",
                    )}
                  >
                    {["Default Sorting", "Price: Low to High", "Price: High to Low", "Newest First", "Most Popular"].map((option) => (
                      <button
                        key={option}
                        type="button"
                        onClick={() => {
                          setSortValue(option);
                          setSortOpen(false);
                        }}
                        className={cn(
                          "flex w-full items-center justify-between px-4 py-2.5 text-left text-sm transition",
                          sortValue === option
                            ? theme === "light"
                              ? "bg-sky-50 text-sky-600"
                              : "bg-slate-950 text-sky-400"
                            : theme === "light"
                              ? "hover:bg-slate-50"
                              : "hover:bg-slate-800",
                        )}
                      >
                        {option}
                        {sortValue === option && <ArrowRightIcon className="h-4 w-4" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-3">
              <span className="text-sm font-semibold">Active Filter</span>
              {activeFilters.map((filter) => (
                <button
                  key={`${filter}-${activeFilters.indexOf(filter)}`}
                  type="button"
                  onClick={() => removeActiveFilter(filter)}
                  className="inline-flex items-center gap-1.5 rounded-full bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-sky-500"
                >
                  {filter}
                  <span className="inline-flex h-4 w-4 items-center justify-center rounded-full bg-white/20">
                    <CloseIcon className="h-3 w-3" />
                  </span>
                </button>
              ))}
              <button
                type="button"
                onClick={() => setActiveFilters([])}
                className="text-sm font-semibold text-sky-600 transition hover:underline"
              >
                Clear All
              </button>
            </div>

            {/* Tabs */}
            <div className="mt-6 flex max-w-full flex-nowrap items-center gap-1.5 overflow-x-auto pb-1 [-ms-overflow-style:none] [scrollbar-width:none] xs:gap-3 [&::-webkit-scrollbar]:hidden">
              {TABS.map((tabDef) => {
                const isActive = tab === tabDef.key;
                return (
                  <button
                    key={tabDef.key}
                    type="button"
                    onClick={() => setTab(tabDef.key)}
                    className={cn(
                      "shrink-0 whitespace-nowrap rounded-full border px-3 py-1.5 text-xs font-semibold transition xs:px-6 xs:text-sm",
                      isActive
                        ? "border-sky-500 bg-sky-500 text-white shadow-lg shadow-sky-500/20"
                        : theme === "light"
                          ? "border-sky-500 bg-white text-sky-600 hover:bg-sky-50"
                          : "border-sky-500 bg-slate-950 text-sky-400 hover:bg-slate-900",
                    )}
                  >
                    {tabDef.label}
                  </button>
                );
              })}
            </div>

            {/* Card grid */}
            <div className="mt-6 grid grid-cols-1 gap-4 xs:grid-cols-2 sm:grid-cols-3 lg:gap-5 xl:grid-cols-4 2xl:grid-cols-5">
              {pageClasses.map((card, index) => (
                <ClassCardItem
                  key={card.id}
                  card={card}
                  theme={theme}
                  index={index}
                  isWishlisted={Boolean(wishlist[card.id])}
                  onToggleWishlist={() => toggleWishlist(card.id)}
                />
              ))}
            </div>

            {/* Pagination */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => setPage((current) => Math.max(1, current - 1))}
                className={cn(
                  "inline-flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold transition",
                  theme === "light"
                    ? "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                    : "border border-slate-700 bg-slate-950 text-slate-300 hover:bg-slate-800",
                )}
              >
                First
              </button>
              <button
                type="button"
                onClick={() => setPage((current) => Math.max(1, current - 1))}
                className={cn(
                  "inline-flex h-9 w-9 items-center justify-center rounded-full transition",
                  theme === "light"
                    ? "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                    : "border border-slate-700 bg-slate-950 text-slate-300 hover:bg-slate-800",
                )}
              >
                <ChevronLeftIcon className="h-4 w-4" />
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).slice(0, 5).map((num) => {
                const isActive = page === num;
                return (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setPage(num)}
                    className={cn(
                      "inline-flex h-9 min-w-9 items-center justify-center rounded-full px-3 text-sm font-semibold transition",
                      isActive
                        ? "bg-sky-600 text-white shadow-md shadow-sky-600/20"
                        : theme === "light"
                          ? "text-slate-700 hover:bg-slate-100"
                          : "text-slate-300 hover:bg-slate-800",
                    )}
                  >
                    {num}
                  </button>
                );
              })}
              <span className={cn("px-2 text-sm", theme === "light" ? "text-slate-500" : "text-slate-400")}>...</span>
              {Array.from({ length: totalPages }, (_, i) => i + 1).slice(Math.max(5, totalPages - 3)).map((num) => {
                const isActive = page === num;
                return (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setPage(num)}
                    className={cn(
                      "inline-flex h-9 min-w-9 items-center justify-center rounded-full px-3 text-sm font-semibold transition",
                      isActive
                        ? "bg-sky-600 text-white shadow-md shadow-sky-600/20"
                        : theme === "light"
                          ? "text-slate-700 hover:bg-slate-100"
                          : "text-slate-300 hover:bg-slate-800",
                    )}
                  >
                    {num}
                  </button>
                );
              })}
              <button
                type="button"
                onClick={() => setPage((current) => Math.min(totalPages, current + 1))}
                className={cn(
                  "inline-flex h-9 w-9 items-center justify-center rounded-full transition",
                  theme === "light"
                    ? "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                    : "border border-slate-700 bg-slate-950 text-slate-300 hover:bg-slate-800",
                )}
              >
                <ChevronRightIcon className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setPage(totalPages)}
                className={cn(
                  "inline-flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold transition",
                  theme === "light"
                    ? "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                    : "border border-slate-700 bg-slate-950 text-slate-300 hover:bg-slate-800",
                )}
              >
                Last
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Filter drawer for 0-1023px */}
      <div className={cn("fixed inset-0 z-50 lg:hidden", isFilterDrawerOpen ? "pointer-events-auto" : "pointer-events-none")}>
        <div
          className={cn("absolute inset-0 bg-black/60 transition-opacity", isFilterDrawerOpen ? "opacity-100" : "opacity-0")}
          onClick={() => setIsFilterDrawerOpen(false)}
        />
        <aside
          className={cn(
            "absolute right-0 top-0 flex h-full w-full max-w-sm transform flex-col transition-transform duration-300",
            isFilterDrawerOpen ? "translate-x-0" : "translate-x-full",
            theme === "light" ? "bg-white text-slate-900" : "bg-slate-900 text-white",
          )}
        >
          <div
            className={cn(
              "flex items-center justify-between border-b px-5 py-4",
              theme === "light" ? "border-slate-200" : "border-slate-800",
            )}
          >
            <div>
              <p className="text-base font-bold">Filter Options</p>
              <p className={cn("text-xs", theme === "light" ? "text-slate-500" : "text-slate-400")}>
                Choose grade, subject, and class type
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsFilterDrawerOpen(false)}
              className={cn(
                "inline-flex h-10 w-10 items-center justify-center rounded-full border",
                theme === "light" ? "border-slate-200 bg-white" : "border-slate-800 bg-slate-950",
              )}
            >
              <CloseIcon className="h-5 w-5" />
            </button>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
            <FilterOptions
              theme={theme}
              selectedFilterCheckboxes={selectedFilterCheckboxes}
              onToggleCheckbox={toggleCheckbox}
            />
          </div>

          <div
            className={cn(
              "grid grid-cols-2 gap-3 border-t px-5 py-4",
              theme === "light" ? "border-slate-200" : "border-slate-800",
            )}
          >
            <button
              type="button"
              onClick={() => setSelectedFilterCheckboxes([])}
              className={cn(
                "rounded-2xl border px-4 py-3 text-sm font-semibold transition",
                theme === "light"
                  ? "border-slate-200 bg-white text-slate-900 hover:bg-slate-50"
                  : "border-slate-800 bg-slate-950 text-white hover:bg-slate-800",
              )}
            >
              Clear
            </button>
            <button
              type="button"
              onClick={() => setIsFilterDrawerOpen(false)}
              className="rounded-2xl bg-sky-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-sky-500"
            >
              Apply Filters
            </button>
          </div>
        </aside>
      </div>
    </>
  );
}

/* ============================================
   OTHER PAGES (About, Contact, Dashboard, etc.)
   ============================================ */

function ContentPage({ page, theme, isAuthenticated }: { page: Exclude<Page, "classes">; theme: Theme; isAuthenticated: boolean }) {
  const details = PAGE_DETAILS[page];

  return (
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <section
        className={cn(
          "overflow-hidden rounded-[2rem] border p-6 shadow-xl transition-colors duration-300 lg:p-10",
          theme === "light" ? "border-slate-200 bg-white shadow-slate-200/70" : "border-slate-800 bg-slate-900 shadow-black/20",
        )}
      >
        <div className="grid gap-8 lg:grid-cols-[1.25fr_0.75fr] lg:items-start">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <span
                className={cn(
                  "rounded-full px-3 py-1 text-xs font-bold uppercase tracking-[0.2em]",
                  theme === "light" ? "bg-sky-50 text-sky-600" : "bg-slate-950 text-sky-400",
                )}
              >
                {details.eyebrow}
              </span>
              <span
                className={cn(
                  "rounded-full px-3 py-1 text-xs font-semibold",
                  theme === "light" ? "bg-slate-100 text-slate-600" : "bg-slate-950 text-slate-300",
                )}
              >
                {isAuthenticated ? "Signed in view" : "Guest view"}
              </span>
              <span
                className={cn(
                  "rounded-full px-3 py-1 text-xs font-semibold",
                  theme === "light" ? "bg-slate-100 text-slate-600" : "bg-slate-950 text-slate-300",
                )}
              >
                {theme === "light" ? "Light theme" : "Dark theme"}
              </span>
            </div>

            <h1 className="mt-5 max-w-3xl text-3xl font-black tracking-tight sm:text-4xl lg:text-5xl">
              {details.title}
            </h1>
            <p className={cn("mt-4 max-w-2xl text-base leading-7 sm:text-lg", theme === "light" ? "text-slate-600" : "text-slate-300")}>
              {details.description}
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              {!isAuthenticated ? (
                <button
                  type="button"
                  className="rounded-full bg-sky-600 px-6 py-3 text-sm font-semibold text-white transition hover:bg-sky-500"
                >
                  Sign Up / Sign In Preview
                </button>
              ) : (
                <button
                  type="button"
                  className="rounded-full bg-sky-600 px-6 py-3 text-sm font-semibold text-white transition hover:bg-sky-500"
                >
                  Open Profile Page
                </button>
              )}
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1">
            {[
              {
                label: "Current page",
                value: page.charAt(0).toUpperCase() + page.slice(1),
              },
              {
                label: "Theme",
                value: theme === "light" ? "Light" : "Dark",
              },
              {
                label: "Utility mode",
                value: isAuthenticated ? "Signed in" : "Guest mode",
              },
            ].map((item) => (
              <div
                key={item.label}
                className={cn(
                  "rounded-3xl border p-4",
                  theme === "light" ? "border-slate-200 bg-slate-50" : "border-slate-800 bg-slate-950",
                )}
              >
                <p className={cn("text-xs font-bold uppercase tracking-[0.2em]", theme === "light" ? "text-slate-400" : "text-slate-500")}>
                  {item.label}
                </p>
                <p className="mt-3 text-base font-semibold sm:text-lg">{item.value}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mt-6 grid gap-6 lg:grid-cols-3">
        {details.cards.map((card) => (
          <article
            key={card.title}
            className={cn(
              "rounded-[1.75rem] border p-5 transition-colors duration-300",
              theme === "light" ? "border-slate-200 bg-white" : "border-slate-800 bg-slate-900",
            )}
          >
            <p className={cn("text-xs font-bold uppercase tracking-[0.2em]", theme === "light" ? "text-sky-600" : "text-sky-400")}>
              {card.meta}
            </p>
            <h2 className="mt-3 text-xl font-bold">{card.title}</h2>
            <p className={cn("mt-3 text-sm leading-7", theme === "light" ? "text-slate-600" : "text-slate-300")}>
              {card.description}
            </p>
          </article>
        ))}
      </section>
    </main>
  );
}

/* ============================================
   MAIN APP
   ============================================ */

export default function App() {
  const [theme, setTheme] = useState<Theme>(getInitialTheme);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(getInitialAuth);
  const [page, setPage] = useState<Page>(getInitialPage);
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isMobileCategoryOpen, setIsMobileCategoryOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const categoryRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const wishlistCount = 2;
  const cartCount = 1;

  const searchItems = useMemo<SearchItem[]>(() => {
    return [
      ...NAV_ITEMS.map((item) => ({ label: item.label, description: "Page", page: item.key })),
      { label: "Help Center", description: "Support", page: "support" },
      ...CATEGORY_GROUPS.flatMap((group) => [
        { label: group.title, description: "Category", page: "home" as Page },
        ...group.items.map((item) => ({ label: item, description: group.title, page: "home" as Page })),
      ]),
    ];
  }, []);

  const filteredSearchItems = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) {
      return searchItems.slice(0, 7);
    }
    return searchItems
      .filter((item) => `${item.label} ${item.description}`.toLowerCase().includes(query))
      .slice(0, 7);
  }, [searchItems, searchQuery]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem("learnex-theme", theme);
    }
  }, [theme]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem("learnex-auth", String(isAuthenticated));
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (!isSearchOpen) {
      return;
    }
    const timeout = window.setTimeout(() => searchInputRef.current?.focus(), 80);
    return () => window.clearTimeout(timeout);
  }, [isSearchOpen]);

  useEffect(() => {
    const handleHashChange = () => setPage(getInitialPage());
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  useEffect(() => {
    const handleMouseDown = (event: MouseEvent) => {
      const target = event.target as Node;
      if (categoryRef.current && !categoryRef.current.contains(target)) {
        setIsCategoryOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(target)) {
        setIsProfileOpen(false);
      }
      if (searchRef.current && !searchRef.current.contains(target)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener("mousedown", handleMouseDown);
    return () => document.removeEventListener("mousedown", handleMouseDown);
  }, []);

  useEffect(() => {
    document.body.style.overflow = isDrawerOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isDrawerOpen]);

  const navigate = (nextPage: Page) => {
    setPage(nextPage);
    window.location.hash = nextPage;
    setIsCategoryOpen(false);
    setIsProfileOpen(false);
    setIsDrawerOpen(false);
  };

  const toggleTheme = () => setTheme((current) => (current === "light" ? "dark" : "light"));

  const signIn = () => {
    setIsAuthenticated(true);
    setIsProfileOpen(false);
    navigate("dashboard");
  };

  const signOut = () => {
    setIsAuthenticated(false);
    setIsProfileOpen(false);
    navigate("classes");
  };

  const onSearchResultClick = (item: SearchItem) => {
    setSearchQuery(item.label);
    setIsSearchOpen(false);
    navigate(item.page);
  };

  const onCategoryClick = (item: string) => {
    setSearchQuery(item);
    setIsCategoryOpen(false);
    if (item === "All") {
      navigate("classes");
    } else {
      navigate("home");
    }
  };

  return (
    <div
      className={cn(
        "min-h-screen transition-colors duration-300",
        theme === "light" ? "bg-slate-100 text-slate-900" : "bg-slate-950 text-white",
      )}
    >
      {/* Header */}
      <header className="sticky top-0 z-40">
        <div
          className={cn(
            "border-b transition-colors duration-300",
            theme === "light" ? "border-slate-200 bg-white/95 backdrop-blur" : "border-slate-800 bg-black/95 backdrop-blur",
          )}
        >
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
            <button type="button" onClick={() => navigate("classes")} className="flex items-center gap-3 text-left">
              <div
                className={cn(
                  "flex h-14 w-14 items-center justify-center rounded-2xl",
                  theme === "light" ? "bg-sky-50 text-sky-600" : "bg-slate-900 text-sky-400",
                )}
              >
                <LogoMark className="h-9 w-9" />
              </div>
              <div>
                <div
                  className={cn(
                    "text-2xl font-black tracking-tight sm:text-3xl",
                    theme === "light" ? "text-sky-600" : "text-sky-400",
                  )}
                >
                  Learnex.LK
                </div>
                <p className={cn("text-[11px] font-medium sm:text-xs", theme === "light" ? "text-slate-500" : "text-slate-400")}>
                  Learn Smarter • Achieve Greater
                </p>
              </div>
            </button>

            {/* Desktop nav */}
            <div className="hidden flex-1 items-center justify-end gap-6 nav:flex lg:gap-8">
              <nav className="flex items-center gap-5 lg:gap-8">
                {NAV_ITEMS.map((item) => {
                  const isActive = page === item.key;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => navigate(item.key)}
                      className={cn(
                        "border-b-2 pb-1 text-sm font-semibold transition",
                        isActive
                          ? theme === "light"
                            ? "border-sky-500 text-sky-600"
                            : "border-sky-500 text-sky-400"
                          : theme === "light"
                            ? "border-transparent text-slate-700 hover:text-sky-600"
                            : "border-transparent text-slate-200 hover:text-sky-400",
                      )}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </nav>

              <button
                type="button"
                onClick={() => navigate("contact")}
                className="rounded-full bg-sky-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-sky-500 lg:px-7 lg:py-3"
              >
                Contact Us
              </button>

              <div className={cn("h-8 w-px", theme === "light" ? "bg-slate-200" : "bg-slate-700")} />

              <div className="flex items-center gap-3">
                <TooltipIconButton theme={theme} label="Help" onClick={() => navigate("support")}>
                  <HelpIcon className="h-5 w-5" />
                </TooltipIconButton>
                <TooltipIconButton theme={theme} label="Theme" onClick={toggleTheme}>
                  {theme === "light" ? <MoonIcon className="h-5 w-5" /> : <SunIcon className="h-5 w-5" />}
                </TooltipIconButton>
              </div>
            </div>

            {/* Mobile controls */}
            <div className="flex items-center gap-2 nav:hidden">
              <TooltipIconButton theme={theme} label="Help" onClick={() => navigate("support")}>
                <HelpIcon className="h-5 w-5" />
              </TooltipIconButton>
              <TooltipIconButton theme={theme} label="Theme" onClick={toggleTheme}>
                {theme === "light" ? <MoonIcon className="h-5 w-5" /> : <SunIcon className="h-5 w-5" />}
              </TooltipIconButton>
              <button
                type="button"
                aria-label="Open menu"
                onClick={() => setIsDrawerOpen(true)}
                className={cn(
                  "inline-flex h-11 w-11 items-center justify-center rounded-full border transition",
                  theme === "light"
                    ? "border-slate-200 bg-white text-slate-900 hover:bg-slate-50"
                    : "border-slate-800 bg-black text-white hover:bg-slate-900",
                )}
              >
                <MenuIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Secondary bar */}
        <div className={cn(theme === "light" ? "bg-sky-500 text-white" : "bg-blue-700 text-white")}>
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
            <div ref={categoryRef} className="relative">
              <button
                type="button"
                onClick={() => setIsCategoryOpen((current) => !current)}
                className="inline-flex items-center gap-2 text-sm font-semibold transition hover:opacity-90 sm:text-base"
              >
                <GridIcon className="h-5 w-5" />
                <span>Categories</span>
                <ChevronDownIcon className={cn("h-4 w-4 transition", isCategoryOpen && "rotate-180")} />
              </button>

              {isCategoryOpen && (
                <div
                  className={cn(
                    "absolute left-0 top-full z-50 mt-3 w-[min(92vw,780px)] overflow-hidden rounded-3xl border shadow-2xl",
                    theme === "light" ? "border-slate-200 bg-white text-slate-900" : "border-slate-800 bg-slate-900 text-white",
                  )}
                >
                  <div className="grid gap-5 p-5 sm:grid-cols-2 xl:grid-cols-4">
                    {CATEGORY_GROUPS.map((group) => (
                      <div
                        key={group.title}
                        className={cn(
                          "rounded-2xl border p-4",
                          theme === "light" ? "border-slate-100 bg-slate-50" : "border-slate-800 bg-slate-950",
                        )}
                      >
                        <h3 className={cn("text-sm font-bold", theme === "light" ? "text-sky-600" : "text-sky-400")}>
                          {group.title}
                        </h3>
                        <div className="mt-3 space-y-2">
                          {group.items.map((item) => (
                            <button
                              key={item}
                              type="button"
                              onClick={() => onCategoryClick(item)}
                              className={cn(
                                "block text-left text-sm transition",
                                theme === "light" ? "text-slate-600 hover:text-sky-600" : "text-slate-300 hover:text-sky-400",
                              )}
                            >
                              {item}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2.5">
              <div ref={searchRef} className="relative">
                <button
                  type="button"
                  aria-label="Open search"
                  onClick={() => setIsSearchOpen((current) => !current)}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-full text-white transition hover:bg-white/10"
                >
                  <SearchIcon className="h-5 w-5" />
                </button>

                {isSearchOpen && (
                  <div
                    className={cn(
                      "absolute right-0 top-full z-50 mt-3 w-[min(92vw,440px)] rounded-3xl border p-4 shadow-2xl",
                      theme === "light" ? "border-slate-200 bg-white text-slate-900" : "border-slate-800 bg-slate-900 text-white",
                    )}
                  >
                    <div
                      className={cn(
                        "flex items-center gap-3 rounded-2xl border px-4 py-3",
                        theme === "light" ? "border-slate-200 bg-slate-50" : "border-slate-800 bg-slate-950",
                      )}
                    >
                      <SearchIcon className={cn("h-5 w-5", theme === "light" ? "text-slate-400" : "text-slate-500")} />
                      <input
                        ref={searchInputRef}
                        value={searchQuery}
                        onChange={(event) => setSearchQuery(event.target.value)}
                        placeholder="Search pages, categories, or sub categories"
                        className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
                      />
                      <button
                        type="button"
                        aria-label="Close search"
                        onClick={() => setIsSearchOpen(false)}
                        className={cn(
                          "inline-flex h-8 w-8 items-center justify-center rounded-full transition",
                          theme === "light" ? "text-slate-500 hover:bg-white" : "text-slate-300 hover:bg-slate-800",
                        )}
                      >
                        <CloseIcon className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="mt-4">
                      <div className="mb-3 flex items-center justify-between">
                        <p className={cn("text-xs font-semibold uppercase tracking-[0.2em]", theme === "light" ? "text-slate-400" : "text-slate-500")}>
                          Quick results
                        </p>
                        {searchQuery && (
                          <button
                            type="button"
                            onClick={() => setSearchQuery("")}
                            className={cn("text-xs font-semibold", theme === "light" ? "text-sky-600" : "text-sky-400")}
                          >
                            Clear
                          </button>
                        )}
                      </div>

                      <div className="space-y-2">
                        {filteredSearchItems.length > 0 ? (
                          filteredSearchItems.map((item) => (
                            <button
                              key={`${item.label}-${item.description}`}
                              type="button"
                              onClick={() => onSearchResultClick(item)}
                              className={cn(
                                "flex w-full items-center justify-between rounded-2xl px-4 py-3 text-left transition",
                                theme === "light" ? "bg-slate-50 hover:bg-sky-50" : "bg-slate-950 hover:bg-slate-800",
                              )}
                            >
                              <div>
                                <p className="text-sm font-semibold">{item.label}</p>
                                <p className={cn("text-xs", theme === "light" ? "text-slate-500" : "text-slate-400")}>
                                  {item.description}
                                </p>
                              </div>
                              <ArrowRightIcon className={cn("h-4 w-4", theme === "light" ? "text-sky-600" : "text-sky-400")} />
                            </button>
                          ))
                        ) : (
                          <div
                            className={cn(
                              "rounded-2xl border px-4 py-6 text-center text-sm",
                              theme === "light" ? "border-slate-200 text-slate-500" : "border-slate-800 text-slate-400",
                            )}
                          >
                            No results found for &ldquo;{searchQuery}&rdquo;.
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {isAuthenticated && (
                <>
                  <button
                    type="button"
                    onClick={() => navigate("wishlist")}
                    aria-label="Open wishlist"
                    className="relative inline-flex h-10 w-10 items-center justify-center rounded-full text-white transition hover:bg-white/10"
                  >
                    <HeartIcon className="h-5 w-5" />
                    <span className="absolute right-0.5 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-white px-1 text-[10px] font-bold text-sky-600">
                      {wishlistCount}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => navigate("cart")}
                    aria-label="Open cart"
                    className="relative inline-flex h-10 w-10 items-center justify-center rounded-full text-white transition hover:bg-white/10"
                  >
                    <CartIcon className="h-5 w-5" />
                    <span className="absolute right-0.5 top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-white px-1 text-[10px] font-bold text-sky-600">
                      {cartCount}
                    </span>
                  </button>
                </>
              )}

              <div className="hidden h-7 w-px bg-white/35 sm:block" />

              <div
                ref={profileRef}
                className="relative"
                onMouseEnter={() => setIsProfileOpen(true)}
                onMouseLeave={() => setIsProfileOpen(false)}
              >
                <button
                  type="button"
                  onClick={() => setIsProfileOpen((current) => !current)}
                  className="inline-flex items-center gap-2 rounded-full px-2 py-1.5 text-white transition hover:bg-white/10"
                >
                  <span className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/40 bg-white/10">
                    <UserIcon className="h-4.5 w-4.5" />
                  </span>
                  {!isAuthenticated && <span className="hidden text-sm font-semibold sm:inline">Sign Up</span>}
                </button>

                {isProfileOpen && (
                  <div
                    className={cn(
                      "absolute right-0 top-full z-50 mt-3 w-64 rounded-3xl border p-3 shadow-2xl",
                      theme === "light" ? "border-slate-200 bg-white text-slate-900" : "border-slate-800 bg-slate-900 text-white",
                    )}
                  >
                    {isAuthenticated ? (
                      <>
                        <div
                          className={cn(
                            "mb-3 rounded-2xl px-4 py-3",
                            theme === "light" ? "bg-slate-50" : "bg-slate-950",
                          )}
                        >
                          <p className="text-sm font-semibold">Welcome back, Learner</p>
                          <p className={cn("text-xs", theme === "light" ? "text-slate-500" : "text-slate-400")}>
                            Manage your courses, saved items, and account.
                          </p>
                        </div>
                        <div className="space-y-1">
                          <button
                            type="button"
                            onClick={() => navigate("profile")}
                            className={cn(
                              "flex w-full items-center justify-between rounded-2xl px-4 py-3 text-sm font-medium transition",
                              theme === "light" ? "hover:bg-slate-50" : "hover:bg-slate-950",
                            )}
                          >
                            My Profile <ArrowRightIcon className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => navigate("dashboard")}
                            className={cn(
                              "flex w-full items-center justify-between rounded-2xl px-4 py-3 text-sm font-medium transition",
                              theme === "light" ? "hover:bg-slate-50" : "hover:bg-slate-950",
                            )}
                          >
                            Dashboard <ArrowRightIcon className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => navigate("wishlist")}
                            className={cn(
                              "flex w-full items-center justify-between rounded-2xl px-4 py-3 text-sm font-medium transition",
                              theme === "light" ? "hover:bg-slate-50" : "hover:bg-slate-950",
                            )}
                          >
                            Wishlist <ArrowRightIcon className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={signOut}
                            className={cn(
                              "flex w-full items-center justify-between rounded-2xl px-4 py-3 text-sm font-medium transition",
                              theme === "light" ? "text-rose-600 hover:bg-rose-50" : "text-rose-300 hover:bg-rose-950/30",
                            )}
                          >
                            Sign Out <ArrowRightIcon className="h-4 w-4" />
                          </button>
                        </div>
                      </>
                    ) : (
                      <>
                        <div
                          className={cn(
                            "mb-3 rounded-2xl px-4 py-3",
                            theme === "light" ? "bg-slate-50" : "bg-slate-950",
                          )}
                        >
                          <p className="text-sm font-semibold">Join Learnex.LK</p>
                          <p className={cn("text-xs", theme === "light" ? "text-slate-500" : "text-slate-400")}>
                            Sign up or sign in to unlock cart, wishlist, and profile features.
                          </p>
                        </div>
                        <div className="space-y-2">
                          <button
                            type="button"
                            onClick={signIn}
                            className="flex w-full items-center justify-between rounded-2xl bg-sky-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-sky-500"
                          >
                            Quick Sign Up <ArrowRightIcon className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={signIn}
                            className={cn(
                              "flex w-full items-center justify-between rounded-2xl px-4 py-3 text-sm font-semibold transition",
                              theme === "light"
                                ? "border border-slate-200 text-slate-900 hover:bg-slate-50"
                                : "border border-slate-800 text-white hover:bg-slate-950",
                            )}
                          >
                            Sign In <ArrowRightIcon className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => navigate("support")}
                            className={cn(
                              "flex w-full items-center justify-between rounded-2xl px-4 py-3 text-sm font-medium transition",
                              theme === "light" ? "hover:bg-slate-50" : "hover:bg-slate-950",
                            )}
                          >
                            Help Center <ArrowRightIcon className="h-4 w-4" />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      {page === "classes" ? (
        <ClassesPage theme={theme} />
      ) : (
        <ContentPage page={page} theme={theme} isAuthenticated={isAuthenticated} />
      )}

      {/* Mobile drawer */}
      <div className={cn("fixed inset-0 z-50 nav:hidden", isDrawerOpen ? "pointer-events-auto" : "pointer-events-none")}>
        <div
          className={cn("absolute inset-0 bg-black/50 transition-opacity", isDrawerOpen ? "opacity-100" : "opacity-0")}
          onClick={() => setIsDrawerOpen(false)}
        />
        <aside
          className={cn(
            "absolute right-0 top-0 h-full w-full max-w-sm transform overflow-y-auto p-5 transition-transform duration-300",
            isDrawerOpen ? "translate-x-0" : "translate-x-full",
            theme === "light" ? "bg-white text-slate-900" : "bg-slate-900 text-white",
          )}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={cn(
                  "flex h-12 w-12 items-center justify-center rounded-2xl",
                  theme === "light" ? "bg-sky-50 text-sky-600" : "bg-slate-950 text-sky-400",
                )}
              >
                <LogoMark className="h-8 w-8" />
              </div>
              <div>
                <p className={cn("text-lg font-black", theme === "light" ? "text-sky-600" : "text-sky-400")}>
                  Learnex.LK
                </p>
                <p className={cn("text-xs", theme === "light" ? "text-slate-500" : "text-slate-400")}>
                  Mobile navigation
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsDrawerOpen(false)}
              className={cn(
                "inline-flex h-11 w-11 items-center justify-center rounded-full border",
                theme === "light" ? "border-slate-200 bg-white" : "border-slate-800 bg-slate-950",
              )}
            >
              <CloseIcon className="h-5 w-5" />
            </button>
          </div>

          <div
            className={cn(
              "mt-6 flex items-center gap-3 rounded-2xl border px-4 py-3",
              theme === "light" ? "border-slate-200 bg-slate-50" : "border-slate-800 bg-slate-950",
            )}
          >
            <SearchIcon className={cn("h-5 w-5", theme === "light" ? "text-slate-400" : "text-slate-500")} />
            <input
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder="Search categories or pages"
              className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
            />
          </div>

          <div className="mt-6 space-y-2">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.key}
                type="button"
                onClick={() => navigate(item.key)}
                className={cn(
                  "flex w-full items-center justify-between rounded-2xl px-4 py-3 text-left text-sm font-semibold transition",
                  page === item.key
                    ? theme === "light"
                      ? "bg-sky-50 text-sky-600"
                      : "bg-slate-950 text-sky-400"
                    : theme === "light"
                      ? "hover:bg-slate-50"
                      : "hover:bg-slate-950",
                )}
              >
                <span className="flex items-center gap-3">
                  {item.key === "home" ? <GridIcon className="h-4.5 w-4.5" /> : <ArrowRightIcon className="h-4.5 w-4.5" />}
                  {item.label}
                </span>
                <ArrowRightIcon className="h-4 w-4" />
              </button>
            ))}
          </div>

          <div
            className={cn(
              "mt-6 rounded-3xl border p-4",
              theme === "light" ? "border-slate-200 bg-slate-50" : "border-slate-800 bg-slate-950",
            )}
          >
            <button
              type="button"
              onClick={() => setIsMobileCategoryOpen((current) => !current)}
              className="flex w-full items-center justify-between text-left"
            >
              <span className="flex items-center gap-3 text-sm font-semibold">
                <GridIcon className="h-5 w-5" />
                Categories
              </span>
              <ChevronDownIcon className={cn("h-4 w-4 transition", isMobileCategoryOpen && "rotate-180")} />
            </button>

            {isMobileCategoryOpen && (
              <div className="mt-4 space-y-4">
                {CATEGORY_GROUPS.map((group) => (
                  <div key={group.title}>
                    <p className={cn("text-xs font-bold uppercase tracking-[0.2em]", theme === "light" ? "text-sky-600" : "text-sky-400")}>
                      {group.title}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {group.items.map((item) => (
                        <button
                          key={item}
                          type="button"
                          onClick={() => {
                            setSearchQuery(item);
                            setIsDrawerOpen(false);
                            navigate("home");
                          }}
                          className={cn(
                            "rounded-full px-3 py-1.5 text-xs font-medium transition",
                            theme === "light" ? "bg-white text-slate-700 hover:bg-sky-50 hover:text-sky-600" : "bg-slate-900 text-slate-300 hover:text-sky-400",
                          )}
                        >
                          {item}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => navigate("contact")}
              className="rounded-2xl bg-sky-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-sky-500"
            >
              Contact Us
            </button>
            {isAuthenticated ? (
              <button
                type="button"
                onClick={() => navigate("profile")}
                className={cn(
                  "rounded-2xl px-4 py-3 text-sm font-semibold transition",
                  theme === "light"
                    ? "border border-slate-200 bg-white text-slate-900"
                    : "border border-slate-800 bg-slate-900 text-white",
                )}
              >
                My Profile
              </button>
            ) : (
              <button
                type="button"
                onClick={signIn}
                className={cn(
                  "rounded-2xl px-4 py-3 text-sm font-semibold transition",
                  theme === "light"
                    ? "border border-slate-200 bg-white text-slate-900"
                    : "border border-slate-800 bg-slate-900 text-white",
                )}
              >
                Sign Up
              </button>
            )}
          </div>

          {isAuthenticated && (
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => navigate("wishlist")}
                className={cn(
                  "rounded-2xl border px-4 py-3 text-sm font-semibold",
                  theme === "light" ? "border-slate-200 bg-white" : "border-slate-800 bg-slate-900",
                )}
              >
                Wishlist ({wishlistCount})
              </button>
              <button
                type="button"
                onClick={() => navigate("cart")}
                className={cn(
                  "rounded-2xl border px-4 py-3 text-sm font-semibold",
                  theme === "light" ? "border-slate-200 bg-white" : "border-slate-800 bg-slate-900",
                )}
              >
                Cart ({cartCount})
              </button>
            </div>
          )}

          <div className="mt-6 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => navigate("support")}
              className={cn(
                "flex items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold",
                theme === "light" ? "border-slate-200 bg-white" : "border-slate-800 bg-slate-900",
              )}
            >
              <HelpIcon className={cn("h-4.5 w-4.5", theme === "light" ? "text-sky-600" : "text-sky-400")} />
              Help
            </button>
            <button
              type="button"
              onClick={toggleTheme}
              className={cn(
                "flex items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold",
                theme === "light" ? "border-slate-200 bg-white" : "border-slate-800 bg-slate-900",
              )}
            >
              {theme === "light" ? (
                <>
                  <MoonIcon className="h-4.5 w-4.5 text-sky-600" />
                  Dark Mode
                </>
              ) : (
                <>
                  <SunIcon className="h-4.5 w-4.5 text-sky-400" />
                  Light Mode
                </>
              )}
            </button>
          </div>

          {isAuthenticated && (
            <button
              type="button"
              onClick={signOut}
              className={cn(
                "mt-6 w-full rounded-2xl px-4 py-3 text-sm font-semibold",
                theme === "light" ? "bg-rose-50 text-rose-600" : "bg-rose-950/30 text-rose-300",
              )}
            >
              Sign Out
            </button>
          )}
        </aside>
      </div>

      {/* Footer */}
      <footer
        className={cn(
          "mt-4 border-t transition-colors duration-300",
          theme === "light" ? "border-slate-200 bg-slate-50 text-slate-900" : "border-slate-800 bg-black text-white",
        )}
      >
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center gap-8 lg:flex-row lg:items-center lg:justify-between">
            <button type="button" onClick={() => navigate("home")} className="flex items-center gap-3">
              <div
                className={cn(
                  "flex h-12 w-12 items-center justify-center rounded-2xl",
                  theme === "light" ? "bg-sky-50 text-sky-600" : "bg-slate-900 text-sky-400",
                )}
              >
                <LogoMark className="h-8 w-8" />
              </div>
              <div className="text-left">
                <div className={cn("text-xl font-black tracking-tight", theme === "light" ? "text-sky-600" : "text-sky-400")}>
                  Learnex.LK
                </div>
                <p className={cn("text-[11px] font-medium", theme === "light" ? "text-slate-500" : "text-slate-400")}>
                  Learn Smarter • Achieve Greater
                </p>
              </div>
            </button>

            <nav className="flex flex-wrap items-center justify-center gap-x-3 gap-y-2 sm:gap-x-5">
              {FOOTER_LINKS.map((link, index) => (
                <div key={link.label} className="flex items-center gap-3 sm:gap-5">
                  <button
                    type="button"
                    onClick={() => navigate(link.page)}
                    className={cn(
                      "text-sm font-medium transition",
                      theme === "light" ? "text-slate-700 hover:text-sky-600" : "text-slate-200 hover:text-sky-400",
                    )}
                  >
                    {link.label}
                  </button>
                  {index < FOOTER_LINKS.length - 1 && (
                    <span className={cn("h-5 w-px", theme === "light" ? "bg-slate-300" : "bg-slate-700")} />
                  )}
                </div>
              ))}
            </nav>

            <div className="flex items-center gap-3">
              {SOCIAL_ICONS.map(({ label, Icon }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={label}
                  onClick={(event) => event.preventDefault()}
                  className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-sky-600 text-white transition hover:bg-sky-500"
                >
                  <Icon className="h-4.5 w-4.5" />
                </a>
              ))}
            </div>
          </div>

          <div
            className={cn(
              "mt-8 flex flex-col items-center gap-2 border-t pt-6 text-sm sm:flex-row sm:justify-between",
              theme === "light" ? "border-slate-200" : "border-slate-800",
            )}
          >
            <p className={cn("font-medium", theme === "light" ? "text-slate-700" : "text-slate-300")}>
              2025 Learnex.lk
            </p>
            <p className={cn("font-medium", theme === "light" ? "text-slate-700" : "text-slate-300")}>
              Design and Develop By <span className={cn("font-bold", theme === "light" ? "text-sky-600" : "text-sky-400")}>Learnex Team</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}